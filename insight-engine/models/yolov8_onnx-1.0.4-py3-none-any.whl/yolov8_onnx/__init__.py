# WRITER: LauNT # DATE: 05/2024
# FROM: akaOCR Team - QAI

from .main import DetectEngine

__version__ = '1.0.2'
__all__ = ['DetectEngine']
